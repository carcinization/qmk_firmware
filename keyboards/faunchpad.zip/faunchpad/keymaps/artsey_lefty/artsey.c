extern keymap_config_t keymap_config;

uint8_t layernumber=1;



void modify_layernumber(int val)
{
	layernumber=val;
};




#include "macros.c"


