#include "paintbrush.h"
#include "defaultoled.c"

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {

	LAYOUT(
		KC_Q, KC_W, KC_E, KC_R, 
		KC_A, KC_S, KC_D, KC_F),

};

