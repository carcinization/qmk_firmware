




const char base_map[]= "arst\n" 
"oien ";
const char shifted_base_map[]= "ARST\n" 
"OIEN ";
const char num_map[]= " 321\n"
"7654 ";
const char shifted_num_map[]= " #@!\n"
"&^%$ ";
const char sym_map[]= "`;\\!\n" 
"=-?  ";
const char shifted_sym_map[]= "~:|!\n"
"+_?  ";
const char brac_map[]= "{)( \n"
"}][} ";
const char shifted_brac_map[]= "{)( \n"
"}}{} ";
static char const nav_map[] PROGMEM = {0x1E, 0x11, 0x18, 0x10, 0x20, 0x1F, 0x1B, 0x19, 0x1A, 0
	};
static char const mou_map[] PROGMEM = {0x1E, 0x32, 0x18, 0x31, 0x20, 0x1F, 0x1B, 0x19, 0x1A, 0
	};