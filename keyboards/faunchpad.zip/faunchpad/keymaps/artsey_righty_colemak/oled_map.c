




const char base_map[]= "tsra\n" 
"neio ";
const char shifted_base_map[]= "TSRA\n" 
"NEIO ";
const char num_map[]= "123 \n"
"4567 ";
const char shifted_num_map[]= "!@# \n"
"$%^& ";
const char sym_map[]= "!\\;`\n" 
" ?-= ";
const char shifted_sym_map[]= "!|:~\n"
" ?_+ ";
const char brac_map[]= " (){\n"
"}[]} ";
const char shifted_brac_map[]= " (){\n"
"}{}} ";
static char const nav_map[] PROGMEM = {0x11, 0x18, 0x10, 0x1E, 0x20, 0x1B, 0x19, 0x1A, 0x1F, 0
	};									
static char const mou_map[] PROGMEM = {0x31, 0x18, 0x32, 0x1E, 0x20, 0x1B, 0x19, 0x1A, 0x1F, 0
	};									