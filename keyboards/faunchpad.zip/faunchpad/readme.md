The Paintbrush
A small keyboard design for those who cannot or prefer not use 'traditional' keyboard designs.

This project aims to create a small keyboard design that is adaptable and flexible. Especially for those with disabilities, those who cannot type on traditional keyboads and those that prefer not use traditional keyboards.

The current version of The Painbrush is version 4. 

More information about The Paintbrush is available at https://github.com/artseyio/thepaintbrush
